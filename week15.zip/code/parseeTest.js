var parser = require("./parser1")


parser.parseHTML(`
<script>a</script>`)